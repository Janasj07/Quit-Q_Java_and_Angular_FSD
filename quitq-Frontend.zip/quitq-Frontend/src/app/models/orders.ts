export interface Orders {
    orderId: number; 
    customerId: number; 
    orderDate: Date; 
    status: string; 
    totalAmount: number; 
  }
  