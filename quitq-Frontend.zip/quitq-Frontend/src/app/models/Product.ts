
export interface product{

    productId:number;
    name:string;
    description:string;
    price:number;
    stock:number;
    supplierId:number;
    imageUrl:string;
    quantity:number;

}