
export interface customer{

    customerId:number;
    name:string;
    email:string;
    password:string;
    address:string;
    mobileNumber:number;
    
}