export interface ProductCategory {
    id?: number; // Optional if ID is auto-generated
    name: string;
    description: string;
    // Add other fields as necessary
  }
  