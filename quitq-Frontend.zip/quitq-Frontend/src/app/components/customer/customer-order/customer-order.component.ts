import { Component } from '@angular/core';

interface Order {
  id: number;
  status: string;
  date: string;
  total: number;
}

@Component({
  selector: 'app-customer-order',
  templateUrl: './customer-order.component.html',
  styleUrls: ['./customer-order.component.css']
})
export class CustomerOrderComponent {
 
  orders: Order[] = [
    { id: 3, status: 'processing', date: '2025-07-16', total: 4000 },
    { id: 2, status: 'delivered', date: '2025-07-05', total: 48500 },
    { id: 1, status: 'delivered', date: '2025-07-05', total: 25000 },
  ];

  
  viewOrderDetails(orderId: number): void {
    console.log(`Viewing details for Order ID: ${orderId}`);
    
  }
}
