import { Component } from '@angular/core';
import { supplier } from 'src/app/models/Supplier';
@Component({
  selector: 'app-supplier-dashboard',
  templateUrl: './supplier-dashboard.component.html',
  styleUrls: ['./supplier-dashboard.component.css']
})
export class SupplierDashboardComponent {

}
