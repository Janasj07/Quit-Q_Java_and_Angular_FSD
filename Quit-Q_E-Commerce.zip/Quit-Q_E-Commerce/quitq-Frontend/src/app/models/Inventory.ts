export interface Inventory {
    
    inventoryId: number,
    productId: number,
    stockQuantity: number,
    stockValue: number,
    status: string
 
}