export interface Admin {
   adminId:number;
    name: string;
    email: string;
    password: string;
    role: string; 
  }
  