
export interface supplier{

    supplierId:number;
    name:string;
    email:string;
    password:string;
    address:string;
    mobileNumber:number;
    companyName:string;
    
}