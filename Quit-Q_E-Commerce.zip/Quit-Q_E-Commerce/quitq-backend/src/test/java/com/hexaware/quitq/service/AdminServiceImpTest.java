package com.hexaware.quitq.service;

import com.hexaware.quitq.dto.AdminDTO;
import com.hexaware.quitq.entities.Admin;
import com.hexaware.quitq.entities.UserInfo;
import com.hexaware.quitq.exception.AdminAlreadyExistsException;
import com.hexaware.quitq.exception.AdminNotFoundException;
import com.hexaware.quitq.exception.ProductNotFoundException;
import com.hexaware.quitq.repository.IAdminRepository;
import com.hexaware.quitq.repository.UserInfoRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.*;
import org.springframework.security.crypto.password.PasswordEncoder;

import java.util.*;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

public class AdminServiceImpTest {

    @Mock
    private IAdminRepository adminRepo;

    @Mock
    private UserInfoRepository userRepo;

    @Mock
    private PasswordEncoder passwordEncoder;

    @InjectMocks
    private AdminServiceImp service;

    private AdminDTO adminDTO;
    private Admin admin;

    @BeforeEach
    public void setup() {
        MockitoAnnotations.openMocks(this);

        adminDTO = new AdminDTO();
        adminDTO.setAdminId(1);
        adminDTO.setName("SuperAdmin");
        adminDTO.setEmail("admin@quitq.com");
        adminDTO.setPassword("Admin123");
        adminDTO.setRole("ADMIN");

        admin = new Admin(1, "SuperAdmin", "admin@quitq.com", "encodedPwd", "ADMIN");
    }

    @Test
    public void testAddAdmin_Success() {
        when(adminRepo.findByEmail(adminDTO.getEmail())).thenReturn(Optional.empty());
        when(passwordEncoder.encode(adminDTO.getPassword())).thenReturn("encodedPwd");
        when(adminRepo.save(any(Admin.class))).thenReturn(admin);
        when(userRepo.save(any(UserInfo.class))).thenReturn(new UserInfo());

        AdminDTO result = service.addAdmin(adminDTO);

        assertNotNull(result);
        assertEquals("SuperAdmin", result.getName());
        verify(adminRepo).save(any(Admin.class));
        verify(userRepo).save(any(UserInfo.class));
    }

    @Test
    public void testAddAdmin_AlreadyExists() {
        when(adminRepo.findByEmail(adminDTO.getEmail())).thenReturn(Optional.of(admin));

        assertThrows(AdminAlreadyExistsException.class, () -> service.addAdmin(adminDTO));
    }

    @Test
    public void testUpdateAdmin_Success() {
        Admin updatedAdmin = new Admin(1, "SuperAdmin", "admin@quitq.com", "encodedPwd", "SUPERADMIN");

        when(adminRepo.findById(1)).thenReturn(Optional.of(admin));
        when(passwordEncoder.encode("Admin123")).thenReturn("encodedPwd");
        when(adminRepo.save(any(Admin.class))).thenReturn(updatedAdmin);
        when(userRepo.findByEmail("admin@quitq.com")).thenReturn(Optional.of(new UserInfo()));

        adminDTO.setRole("SUPERADMIN");

        AdminDTO result = service.updateAdmin(adminDTO);

        assertEquals("SUPERADMIN", result.getRole());
        verify(adminRepo).save(any(Admin.class));
        verify(userRepo).save(any(UserInfo.class));
    }

    @Test
    public void testUpdateAdmin_NotFound() {
        when(adminRepo.findById(1)).thenReturn(Optional.empty());

        assertThrows(AdminNotFoundException.class, () -> service.updateAdmin(adminDTO));
    }

    @Test
    public void testGetAdminById_Success() {
        when(adminRepo.findById(1)).thenReturn(Optional.of(admin));

        AdminDTO result = service.getAdminById(1);

        assertEquals("SuperAdmin", result.getName());
    }

    @Test
    public void testGetAdminById_NotFound() {
        when(adminRepo.findById(1)).thenReturn(Optional.empty());

        assertThrows(AdminNotFoundException.class, () -> service.getAdminById(1));
    }

    @Test
    public void testGetAllAdmins() {
        when(adminRepo.findAll()).thenReturn(List.of(admin));

        List<AdminDTO> result = service.getAllAdmins();

        assertEquals(1, result.size());
        assertEquals("SuperAdmin", result.get(0).getName());
    }

    @Test
    public void testGetAdminByEmail_Success() {
        when(adminRepo.findByEmail("admin@quitq.com")).thenReturn(Optional.of(admin));

        Admin result = service.getAdminByEmail("admin@quitq.com");

        assertEquals("SuperAdmin", result.getName());
    }

    @Test
    public void testGetAdminByEmail_NotFound() {
        when(adminRepo.findByEmail("notfound@quitq.com")).thenReturn(Optional.empty());

        assertThrows(AdminNotFoundException.class, () -> service.getAdminByEmail("notfound@quitq.com"));
    }

    @Test
    public void testDeleteAdminById_Success() {
        when(adminRepo.existsById(1)).thenReturn(true);

        String result = service.deleteAdminById(1);

        assertEquals("Admin deleted successfully", result);
        verify(adminRepo).deleteById(1);
    }

    @Test
    public void testDeleteAdminById_NotFound() {
        when(adminRepo.existsById(1)).thenReturn(false);

        assertThrows(ProductNotFoundException.class, () -> service.deleteAdminById(1));
    }
}
