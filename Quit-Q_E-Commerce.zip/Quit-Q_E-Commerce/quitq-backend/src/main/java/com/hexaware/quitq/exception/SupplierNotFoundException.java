package com.hexaware.quitq.exception;

public class SupplierNotFoundException  extends RuntimeException{

	public SupplierNotFoundException(String message) {
		super(message);
	}

	
}
