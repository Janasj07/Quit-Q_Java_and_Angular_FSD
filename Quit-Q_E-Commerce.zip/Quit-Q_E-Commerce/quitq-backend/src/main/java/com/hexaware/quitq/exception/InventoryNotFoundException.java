package com.hexaware.quitq.exception;

public class InventoryNotFoundException extends RuntimeException {

	    public InventoryNotFoundException(String message) {
	        super(message);
	    }
	

}
