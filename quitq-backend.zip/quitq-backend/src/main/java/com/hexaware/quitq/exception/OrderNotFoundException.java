package com.hexaware.quitq.exception;

public class OrderNotFoundException {

	public OrderNotFoundException(String message) {
		super();
	}

	public String getMessage() {
		// TODO Auto-generated method stub
		return null;
	}

	
}
