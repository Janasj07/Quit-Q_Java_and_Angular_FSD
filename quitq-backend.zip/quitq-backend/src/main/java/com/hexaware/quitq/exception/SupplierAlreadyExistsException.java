package com.hexaware.quitq.exception;

public class SupplierAlreadyExistsException extends RuntimeException {

	public SupplierAlreadyExistsException(String message) {
		super(message);
	}

	
}
