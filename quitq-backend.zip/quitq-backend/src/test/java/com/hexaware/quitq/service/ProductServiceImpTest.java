package com.hexaware.quitq.service;

import com.hexaware.quitq.dto.ProductDTO;
import com.hexaware.quitq.entities.Product;
import com.hexaware.quitq.entities.Supplier;
import com.hexaware.quitq.exception.ProductNotFoundException;
import com.hexaware.quitq.exception.SupplierNotFoundException;
import com.hexaware.quitq.repository.IProductRepository;
import com.hexaware.quitq.repository.ISupplierRepository;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.*;

import java.util.*;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

public class ProductServiceImpTest {

    @Mock
    private IProductRepository repo;

    @Mock
    private ISupplierRepository supplierRepo;

    @InjectMocks
    private ProductServiceImp service;

    private ProductDTO productDTO;
    private Supplier supplier;
    private Product product;

    @BeforeEach
    public void setUp() {
        MockitoAnnotations.openMocks(this);

        supplier = new Supplier();
        supplier.setSupplierId(1);
        supplier.setName("ABC Supplies");

        productDTO = new ProductDTO();
        productDTO.setProductId(1);
        productDTO.setSupplierId(1);
        productDTO.setName("Keyboard");
        productDTO.setCategoryId(2);
        productDTO.setPrice(1200.0);
        productDTO.setStock(10);
        productDTO.setDescription("Mechanical Keyboard");
        productDTO.setImageUrl("keyboard.jpg");

        product = new Product();
        product.setProductId(1);
        product.setSupplier(supplier);
        product.setName("Keyboard");
        product.setCategoryId(2);
        product.setPrice(1200.0);
        product.setStock(10);
        product.setDescription("Mechanical Keyboard");
        product.setImageUrl("keyboard.jpg");
    }

    @Test
    public void testAddProduct_Success() {
        when(supplierRepo.findById(1)).thenReturn(Optional.of(supplier));
        when(repo.save(any(Product.class))).thenReturn(product);

        Product result = service.addProduct(productDTO);

        assertNotNull(result);
        assertEquals("Keyboard", result.getName());
        verify(repo).save(any(Product.class));
    }

    @Test
    public void testAddProduct_SupplierNotFound() {
        when(supplierRepo.findById(1)).thenReturn(Optional.empty());

        assertThrows(SupplierNotFoundException.class, () -> service.addProduct(productDTO));
    }

    @Test
    public void testUpdateProduct_Success() {
        when(repo.findById(1)).thenReturn(Optional.of(product));
        when(supplierRepo.findById(1)).thenReturn(Optional.of(supplier));
        when(repo.save(any(Product.class))).thenReturn(product);

        Product result = service.updateProduct(productDTO);

        assertEquals("Keyboard", result.getName());
    }

    @Test
    public void testUpdateProduct_ProductNotFound() {
        when(repo.findById(1)).thenReturn(Optional.empty());

        assertThrows(ProductNotFoundException.class, () -> service.updateProduct(productDTO));
    }

    @Test
    public void testGetProductById_Success() {
        when(repo.findById(1)).thenReturn(Optional.of(product));

        Product result = service.getProductById(1);

        assertEquals(1, result.getProductId());
    }

    @Test
    public void testGetProductById_NotFound() {
        when(repo.findById(1)).thenReturn(Optional.empty());

        assertThrows(ProductNotFoundException.class, () -> service.getProductById(1));
    }

    @Test
    public void testGetAllProducts() {
        when(repo.findAll()).thenReturn(List.of(product));

        List<Product> result = service.getAllProducts();

        assertEquals(1, result.size());
    }

    @Test
    public void testDeleteProductById_Success() {
        when(repo.existsById(1)).thenReturn(true);
        doNothing().when(repo).deleteById(1);

        String result = service.deleteProductById(1);

        assertEquals("Product deleted successfully", result);
        verify(repo).deleteById(1);
    }

    @Test
    public void testDeleteProductById_NotFound() {
        when(repo.existsById(1)).thenReturn(false);

        assertThrows(ProductNotFoundException.class, () -> service.deleteProductById(1));
    }

    @Test
    public void testGetProductsByPriceRange() {
        when(repo.findProductsByPriceRange(1000, 1500)).thenReturn(List.of(product));

        List<Product> result = service.getProductsByPriceRange(1000, 1500);

        assertEquals(1, result.size());
    }

    @Test
    public void testSearchProductByName() {
        when(repo.findByNameContainingIgnoreCase("key")).thenReturn(List.of(product));

        List<Product> result = service.searchProductByName("key");

        assertEquals(1, result.size());
    }

    @Test
    public void testUpdateProductById_Success() {
        when(repo.findById(1)).thenReturn(Optional.of(product));
        when(supplierRepo.findById(1)).thenReturn(Optional.of(supplier));
        when(repo.save(any(Product.class))).thenReturn(product);

        Product result = service.updateProductById(1, productDTO);

        assertNotNull(result);
        assertEquals("Keyboard", result.getName());
    }

    @Test
    public void testUpdateProductById_ProductNotFound() {
        when(repo.findById(1)).thenReturn(Optional.empty());

        assertThrows(ProductNotFoundException.class, () -> service.updateProductById(1, productDTO));
    }

    @Test
    public void testGetProductBySupplierId() {
        when(repo.findProductsBySupplierId(1)).thenReturn(List.of(product));

        List<Product> result = service.getProductBySupplierId(1);

        assertEquals(1, result.size());
    }
}
