package com.hexaware.quitq.service;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

import java.util.*;

import com.hexaware.quitq.dto.CustomerDTO;
import com.hexaware.quitq.entities.Customer;
import com.hexaware.quitq.entities.UserInfo;
import com.hexaware.quitq.exception.CustomerAlreadyExistsException;
import com.hexaware.quitq.exception.CustomerNotFoundException;
import com.hexaware.quitq.repository.ICustomerRepository;
import com.hexaware.quitq.repository.UserInfoRepository;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.*;
import org.springframework.security.crypto.password.PasswordEncoder;

public class CustomerServiceImpTest {

    @Mock
    private ICustomerRepository repo;

    @Mock
    private UserInfoRepository userRepo;

    @Mock
    private PasswordEncoder passwordEncoder;

    @InjectMocks
    private CustomerServiceImp service;

    private CustomerDTO customerDTO;
    private Customer customer;

    @BeforeEach
    public void setup() {
        MockitoAnnotations.openMocks(this);

        customerDTO = new CustomerDTO();
        customerDTO.setCustomerId(1);
        customerDTO.setName("Alice");
        customerDTO.setEmail("alice@example.com");
        customerDTO.setPassword("Password123");
        customerDTO.setMobileNumber("9876543210");
        customerDTO.setAddress("Bangalore");

        customer = new Customer(1, "Alice", "alice@example.com", "encodedpwd",
                "9876543210", "Bangalore", new Date());
    }

    @Test
    public void testAddCustomer_Success() {
        when(repo.findByEmail(customerDTO.getEmail())).thenReturn(Optional.empty());
        when(passwordEncoder.encode(customerDTO.getPassword())).thenReturn("encodedpwd");
        when(repo.save(any(Customer.class))).thenReturn(customer);
        when(userRepo.save(any(UserInfo.class))).thenReturn(new UserInfo());

        Customer result = service.addCustomer(customerDTO);

        assertNotNull(result);
        assertEquals("alice@example.com", result.getEmail());
        verify(repo, times(1)).save(any(Customer.class));
        verify(userRepo, times(1)).save(any(UserInfo.class));
    }

    @Test
    public void testAddCustomer_AlreadyExists() {
        when(repo.findByEmail(customerDTO.getEmail())).thenReturn(Optional.of(customer));

        assertThrows(CustomerAlreadyExistsException.class, () -> service.addCustomer(customerDTO));
    }

    @Test
    public void testGetCustomerById_Success() {
        when(repo.findById(1)).thenReturn(Optional.of(customer));

        Customer result = service.getCustomerById(1);

        assertEquals("Alice", result.getName());
    }

    @Test
    public void testGetCustomerById_NotFound() {
        when(repo.findById(1)).thenReturn(Optional.empty());

        assertThrows(CustomerNotFoundException.class, () -> service.getCustomerById(1));
    }

    @Test
    public void testGetAllCustomers() {
        when(repo.findAll()).thenReturn(List.of(customer));

        List<Customer> result = service.getAllCustomers();

        assertEquals(1, result.size());
    }

    @Test
    public void testUpdateCustomer_Success() {
        when(repo.findByEmail(customerDTO.getEmail())).thenReturn(Optional.of(customer));
        when(passwordEncoder.encode(customerDTO.getPassword())).thenReturn("newEncodedPwd");
        when(repo.save(any(Customer.class))).thenReturn(customer);

        Customer result = service.updateCustomer(customerDTO);

        assertNotNull(result);
        assertEquals("alice@example.com", result.getEmail());
    }

    @Test
    public void testUpdateCustomer_NotFound() {
        when(repo.findByEmail(customerDTO.getEmail())).thenReturn(Optional.empty());

        assertThrows(CustomerNotFoundException.class, () -> service.updateCustomer(customerDTO));
    }

    @Test
    public void testDeleteCustomerById_Success() {
        when(repo.findById(1)).thenReturn(Optional.of(customer));

        String result = service.deleteCustomerById(1);

        assertEquals("Record Deleted", result);
        verify(repo, times(1)).deleteById(1);
    }

    @Test
    public void testDeleteCustomerById_NotFound() {
        when(repo.findById(1)).thenReturn(Optional.empty());

        assertThrows(CustomerNotFoundException.class, () -> service.deleteCustomerById(1));
    }

    @Test
    public void testGetCustomerByEmail_Success() {
        when(repo.findByEmail("alice@example.com")).thenReturn(Optional.of(customer));

        Customer result = service.getCustomerByEmail("alice@example.com");

        assertEquals("Alice", result.getName());
    }

    @Test
    public void testGetCustomerByEmail_NotFound() {
        when(repo.findByEmail("alice@example.com")).thenReturn(Optional.empty());

        assertThrows(CustomerNotFoundException.class, () -> service.getCustomerByEmail("alice@example.com"));
    }

    @Test
    public void testUpdateAddress_Success() {
        when(repo.findById(1)).thenReturn(Optional.of(customer));
        when(repo.save(any(Customer.class))).thenReturn(customer);

        Customer result = service.updateAddress(1, "Hyderabad");

        assertEquals("Hyderabad", result.getAddress());
    }

    @Test
    public void testUpdateAddress_NotFound() {
        when(repo.findById(1)).thenReturn(Optional.empty());

        assertThrows(CustomerNotFoundException.class, () -> service.updateAddress(1, "Hyderabad"));
    }

    @Test
    public void testGetUserRole_Success() {
        UserInfo user = new UserInfo();
        user.setRoles("CUSTOMER");

        when(userRepo.findByEmail("alice@example.com")).thenReturn(Optional.of(user));

        String role = service.getUserRole("alice@example.com");

        assertEquals("CUSTOMER", role);
    }

    @Test
    public void testGetUserRole_NotFound() {
        when(userRepo.findByEmail("bob@example.com")).thenReturn(Optional.empty());

        assertThrows(CustomerNotFoundException.class, () -> service.getUserRole("bob@example.com"));
    }
}
