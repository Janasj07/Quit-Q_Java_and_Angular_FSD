package com.hexaware.quitq.service;

import com.hexaware.quitq.entities.Inventory;
import com.hexaware.quitq.repository.IInventoryRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.*;

import java.util.*;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

public class InventoryServiceImpTest {

    @InjectMocks
    private InventoryServiceImp service;

    @Mock
    private IInventoryRepository repository;

    private Inventory inventory;

    @BeforeEach
    public void setUp() {
        MockitoAnnotations.openMocks(this);

        inventory = new Inventory();
        inventory.setInventoryId(1);
        inventory.setProductId(101);
        inventory.setStockQuantity(50);
        inventory.setStockValue(5000.0);
        inventory.setStatus("AVAILABLE");
    }

    @Test
    public void testAddInventory_Success() {
        when(repository.save(inventory)).thenReturn(inventory);

        Inventory result = service.addInventory(inventory);

        assertNotNull(result);
        assertEquals(1, result.getInventoryId());
        verify(repository, times(1)).save(inventory);
    }

    @Test
    public void testUpdateInventory_Success() {
        when(repository.findById(1)).thenReturn(Optional.of(inventory));
        when(repository.save(any(Inventory.class))).thenReturn(inventory);

        inventory.setStockQuantity(100);
        Inventory updated = service.updateInventory(inventory);

        assertEquals(100, updated.getStockQuantity());
        verify(repository).save(any(Inventory.class));
    }

    @Test
    public void testUpdateInventory_NotFound() {
        when(repository.findById(999)).thenReturn(Optional.empty());
        inventory.setInventoryId(999);

        RuntimeException ex = assertThrows(RuntimeException.class, () -> {
            service.updateInventory(inventory);
        });

        assertEquals("Inventory not found for ID: 999", ex.getMessage());
    }

    @Test
    public void testGetInventoryById_Found() {
        when(repository.findById(1)).thenReturn(Optional.of(inventory));

        Inventory result = service.getInventoryById(1);

        assertNotNull(result);
        assertEquals(101, result.getProductId());
    }

    @Test
    public void testGetInventoryById_NotFound() {
        when(repository.findById(99)).thenReturn(Optional.empty());

        Inventory result = service.getInventoryById(99);

        assertNull(result);
    }

    @Test
    public void testDeleteInventoryById() {
        doNothing().when(repository).deleteById(1);

        String result = service.deleteInventoryById(1);

        assertEquals("Inventory deleted successfully!", result);
        verify(repository).deleteById(1);
    }

    @Test
    public void testGetAllInventory() {
        when(repository.findAll()).thenReturn(List.of(inventory));

        List<Inventory> result = service.getAllInventory();

        assertEquals(1, result.size());
    }

    @Test
    public void testGetByProductId() {
        when(repository.findByProductId(101)).thenReturn(List.of(inventory));

        List<Inventory> result = service.getByProductId(101);

        assertEquals(1, result.size());
        assertEquals(101, result.get(0).getProductId());
    }

    @Test
    public void testGetByStockGreaterThan() {
        when(repository.findByStockQuantityGreaterThan(40)).thenReturn(List.of(inventory));

        List<Inventory> result = service.getByStockGreaterThan(40);

        assertFalse(result.isEmpty());
        assertTrue(result.get(0).getStockQuantity() > 40);
    }

    @Test
    public void testGetByStatus() {
        when(repository.findByStatus("AVAILABLE")).thenReturn(List.of(inventory));

        List<Inventory> result = service.getByStatus("AVAILABLE");

        assertEquals(1, result.size());
        assertEquals("AVAILABLE", result.get(0).getStatus());
    }
}
