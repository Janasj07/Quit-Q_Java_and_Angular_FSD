package com.hexaware.quitq.service;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

import java.util.Arrays;
import java.util.Date;
import java.util.Optional;

import com.hexaware.quitq.dto.SupplierDTO;
import com.hexaware.quitq.entities.Supplier;
import com.hexaware.quitq.entities.UserInfo;
import com.hexaware.quitq.exception.SupplierAlreadyExistsException;
import com.hexaware.quitq.exception.SupplierNotFoundException;
import com.hexaware.quitq.repository.ISupplierRepository;
import com.hexaware.quitq.repository.UserInfoRepository;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.security.crypto.password.PasswordEncoder;

import java.util.List;

public class SupplierServiceImpTest {

    @Mock
    private ISupplierRepository repo;

    @Mock
    private UserInfoRepository userRepo;

    @Mock
    private PasswordEncoder passwordEncoder;

    @InjectMocks
    private SupplierServiceImp service;

    private SupplierDTO supplierDTO;
    private Supplier supplier;

    @BeforeEach
    public void setup() {
        MockitoAnnotations.openMocks(this);

        supplierDTO = new SupplierDTO();
        supplierDTO.setSupplierId(1);
        supplierDTO.setName("John Doe");
        supplierDTO.setEmail("john@example.com");
        supplierDTO.setPassword("Password123");
        supplierDTO.setMobileNumber("9876543210");
        supplierDTO.setCompanyName("Hexaware Ltd");
        supplierDTO.setAddress("Chennai");

        supplier = new Supplier(1, "John Doe", "john@example.com", "encodedpwd",
                "9876543210", "Hexaware Ltd", "Chennai", new Date());
    }

    @Test
    public void testAddSupplier_Success() {
        when(repo.findByEmail(supplierDTO.getEmail())).thenReturn(Optional.empty());
        when(passwordEncoder.encode(supplierDTO.getPassword())).thenReturn("encodedpwd");
        when(repo.save(any(Supplier.class))).thenReturn(supplier);
        when(userRepo.save(any(UserInfo.class))).thenReturn(new UserInfo());

        Supplier result = service.addSupplier(supplierDTO);

        assertNotNull(result);
        assertEquals(supplierDTO.getEmail(), result.getEmail());
        verify(repo, times(1)).save(any(Supplier.class));
        verify(userRepo, times(1)).save(any(UserInfo.class));
    }

    @Test
    public void testAddSupplier_AlreadyExists() {
        when(repo.findByEmail(supplierDTO.getEmail())).thenReturn(Optional.of(supplier));
        assertThrows(SupplierAlreadyExistsException.class, () -> service.addSupplier(supplierDTO));
    }

    @Test
    public void testGetSupplierById_Success() {
        when(repo.findById(1)).thenReturn(Optional.of(supplier));

        Supplier result = service.getSupplierById(1);

        assertEquals("john@example.com", result.getEmail());
    }

    @Test
    public void testGetSupplierById_NotFound() {
        when(repo.findById(1)).thenReturn(Optional.empty());

        assertThrows(SupplierNotFoundException.class, () -> service.getSupplierById(1));
    }

    @Test
    public void testGetAllSuppliers() {
        when(repo.findAll()).thenReturn(Arrays.asList(supplier));
        List<Supplier> result = service.getAllSuppliers();

        assertEquals(1, result.size());
    }

    @Test
    public void testUpdateSupplier_Success() {
        when(repo.findByEmail(supplierDTO.getEmail())).thenReturn(Optional.of(supplier));
        when(repo.save(any(Supplier.class))).thenReturn(supplier);

        Supplier updated = service.updateSupplier(supplierDTO);
        assertEquals(supplierDTO.getEmail(), updated.getEmail());
    }

    @Test
    public void testUpdateSupplier_NotFound() {
        when(repo.findByEmail(supplierDTO.getEmail())).thenReturn(Optional.empty());

        assertThrows(SupplierNotFoundException.class, () -> service.updateSupplier(supplierDTO));
    }

    @Test
    public void testDeleteSupplierById_Success() {
        when(repo.findById(1)).thenReturn(Optional.of(supplier));

        String result = service.deleteSupplierById(1);

        assertEquals("Record Deleted", result);
        verify(repo).deleteById(1);
    }

    @Test
    public void testDeleteSupplierById_NotFound() {
        when(repo.findById(1)).thenReturn(Optional.empty());

        assertThrows(SupplierNotFoundException.class, () -> service.deleteSupplierById(1));
    }

    @Test
    public void testGetSupplierByEmail_Success() {
        when(repo.findByEmail("john@example.com")).thenReturn(Optional.of(supplier));

        Supplier found = service.getSupplierByEmail("john@example.com");
        assertEquals("John Doe", found.getName());
    }

    @Test
    public void testGetSupplierByEmail_NotFound() {
        when(repo.findByEmail("john@example.com")).thenReturn(Optional.empty());

        assertThrows(SupplierNotFoundException.class, () -> service.getSupplierByEmail("john@example.com"));
    }

    @Test
    public void testGetUserRole_Success() {
        UserInfo user = new UserInfo();
        user.setRoles("SUPPLIER");

        when(userRepo.findByEmail("john@example.com")).thenReturn(Optional.of(user));

        String role = service.getUserRole("john@example.com");
        assertEquals("SUPPLIER", role);
    }

    @Test
    public void testGetUserRole_NotFound() {
        when(userRepo.findByEmail("unknown@example.com")).thenReturn(Optional.empty());

        assertThrows(SupplierNotFoundException.class, () -> service.getUserRole("unknown@example.com"));
    }
}
